# NicheForge — Build Log & Changelog

> Personal AI-powered web studio for building, deploying, and managing niche websites.
> Single HTML file. No server required. Runs in any browser.

---

## Stack
- **Frontend**: Pure HTML + CSS + Vanilla JS (single file, no frameworks)
- **AI Engine**: Anthropic Claude API (`claude-sonnet-4-20250514`)
- **Fonts**: Google Fonts — Syne (headings) + DM Sans (body)
- **Deployment target**: GitHub + Cloudflare Pages
- **Images**: Unsplash API (free) + AI prompt generation

---

## v0.3 — 2026-02-20
### Added
- **🎯 AI Keyword Research** (fully live)
  - Enter seed keyword + optional location + intent filter + count
  - AI returns real keywords with volume, difficulty, intent, CPC, recommended page type
  - Summary stats bar: total volume, avg difficulty, avg CPC, easy wins count
  - Filter buttons: All / Info / How-To / Local / Commercial / Easy Wins
  - Build Page button on each row — pre-fills Page Generator automatically
  - Copy All (tab-separated) and Download CSV buttons
  - Send to Page Generator button (uses top keyword)

### Fixed
- **📱 Mobile sidebar overlap bug**
  - Root cause: sidebar `z-index` (150) was not high enough to cover main content, and `transform: translateX(-100%)` wasn't working cleanly
  - Fix: sidebar now uses `z-index: 500`, overlay uses `z-index: 499`, sidebar translates `-260px` (its actual width) instead of `-100%`
  - Added `document.body.style.overflow = 'hidden'` when sidebar is open to prevent background scroll
  - Sidebar closes automatically when any nav item is tapped on mobile
  - Niche modal on mobile now slides up from bottom (full-width sheet) instead of centre modal

### Improved
- Mobile responsive CSS fully rewritten — cleaner, more specific breakpoints
- `@media (max-width: 768px)` — main tablet/phone layout
- `@media (max-width: 420px)` — small phone tweaks

---

## v0.2 — 2026-02-20
### Added
- **📄 Page Generator** (AI-powered, live)
  - Inputs: site name, page type, keyword, location, site URL, theme colour, brief
  - Template selector: Article Pro, How-To Guide, Local Service, Review Page
  - Toggles: SEO meta tags, Schema JSON-LD, FAQ section, CTA/contact form
  - 4 theme colour palettes: Dark, Light, Bold Blue, Fresh Green
  - 4-step progress tracker with real-time status
  - Live preview in iframe (blob URL)
  - Copy HTML to clipboard
  - Download as `.html` file
  - Generate Another button resets the form

- **🔍 Niche Discovery** (AI-powered, live)
  - Filters: seed topic, min AdSense RPM, competition level
  - AI returns 6 niches with: icon, name, RPM, competition, search volume, description
  - Detail modal: top keywords, content ideas, monetization strategy
  - Build Site → jumps to Create Site with niche pre-filled
  - Default pre-loaded cards for home repair adjacent niches

- **📱 Mobile layout** (first pass — later fixed in v0.3)
  - Mobile topbar with hamburger menu
  - Sidebar overlay

---

## v0.1 — 2026-02-20
### Initial Build
- Full dashboard UI with sidebar navigation
- 8 panels: Dashboard, Create Site, Page Generator, Niche Discovery, SEO Generator, Keywords, Deploy, My Sites
- Dashboard: stats row (4 KPIs), recent sites list, activity feed, quick action cards
- Create Site: 4-step wizard (type → details → SEO config → generate)
- SEO Generator: functional — generates complete meta tags + Open Graph + JSON-LD from form inputs
- Deploy panel: site selector, target (Cloudflare/Vercel/Netlify), domain setup with DNS instructions
- My Sites panel: site list with status badges
- Design system: dark theme (`#0a0a0f` base), accent green (`#00e5a0`), accent purple (`#7c6dfa`)
- Noise texture overlay, ambient glow effect
- Custom scrollbar

---

## Planned / Next
- [ ] **GitHub Push Integration** — connect repo, auto-push generated pages
- [ ] **Cloudflare Deploy Button** — trigger deployment from dashboard
- [ ] **Bulk Page Generator** — generate 5-20 pages from a keyword list in one click
- [ ] **Site Settings panel** — manage domain, GA4 ID, AdSense ID per site
- [ ] **Saved Sites persistence** — localStorage to remember your sites between sessions
- [ ] **Image Search** — Unsplash API integration to fetch and embed real photos
- [ ] **SEO Audit tool** — paste a URL, get a basic on-page SEO score
- [ ] **Content brief generator** — AI builds a full outline before page generation

---

## File Structure
```
nicheforge.html          — Main app (single file, open in browser)
NICHEFORGE_CHANGELOG.md  — This file
```

## How to Use
1. Open `nicheforge.html` in any browser (Chrome recommended)
2. No installation, no server, no login required
3. API calls go to Anthropic — requires active Claude API access
4. Generated pages: copy HTML or download `.html` file, upload to your host

## Notes for Development
- All AI calls use `claude-sonnet-4-20250514` model, `max_tokens: 1000`
- JSON responses are cleaned of markdown fences before parsing
- Mobile breakpoint: `768px` (tablet/phone), `420px` (small phone)
- z-index layers: mob topbar (200), sidebar-overlay (499), sidebar (500), niche modal (300)
